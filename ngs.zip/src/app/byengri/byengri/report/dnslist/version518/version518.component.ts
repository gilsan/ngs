import { Component, OnInit } from "@angular/core";


@Component({
    selector: 'app-ver518',
    templateUrl: './version518.component.html',
    styleUrls: ['./version518.component.scss']
  })
  export class Version518Component implements OnInit {

    
    ngOnInit(): void {
         
    }



  }