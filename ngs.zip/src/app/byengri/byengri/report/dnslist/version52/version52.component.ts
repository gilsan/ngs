import { Component, OnInit } from "@angular/core";


@Component({
    selector: 'app-ver52',
    templateUrl: './version52.component.html',
    styleUrls: ['./version52.component.scss']
  })
  export class Version52Component implements OnInit {

    
    ngOnInit(): void {
         console.log('........');
    }



  }

 
