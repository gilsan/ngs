export interface ITitleList {
  prescription_date: string;
  name: string;
  age: string;
  gender: string;
  patientID: string;
  pathology_num: string;
}


// const patientListResearchRouter = require('./routes/patientlist_Research');
// app.use('/patients_research', patientListResearchRouter);
// router.post('/insert', patientResearchController.setResearchList);
//  const patientResearchController = require('../controller/patientslist_Research');
/////////////

