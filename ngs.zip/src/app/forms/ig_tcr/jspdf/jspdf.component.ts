import { Component , OnInit, OnDestroy, ViewChild, TemplateRef, ElementRef, AfterViewInit } from '@angular/core';


@Component({
  selector: 'app-igtcr-heet',
  templateUrl: './jspdf.component.html',
  styleUrls: ['./jspdf.component.scss']
})
export class JsPDFComponent implements OnInit {


  ngOnInit(): void {

  }

  createChart(): void {

  }


}
