export interface IRegister {
  user_id: string;
  password: string;
  user_nm: string;
  dept: string;
  part: string;
}