export interface IManageFunctions {
  function_id: string; 
  function_name: string; 
  service_status: string; 
  create_date: string; 
  update_date: string; 
}