export interface Comment {
  gene: string;
  variants: string;
  comments: string;
  reference: string;
}
