// private apiUrl = 'http://160.1.17.79:3000';  // EMR 서버
// private apiUrl = 'http://112.169.53.30:3000';

 export const emrUrl = 'http://61.74.215.2:3000'; // 사무실
 
//export const emrUrl = 'http://127.0.0.1:3000';
// export const emrUrl = 'http://160.1.17.79:3000'; // 병원 운영
//export const emrUrl = 'http://160.1.17.79:5000'; // 병원 개발

//

/*
// tslint:disable-next-line:max-line-length
const emrdata = `http://emr012edu.cmcnu.or.kr/cmcnu/.live?submit_id=${submitID}&business_id=li&instcd=012&spcno=${spcno}&formcd=-&rsltflag=O&pid=${pid}&examcd=${examcd}&examflag=${examflag}&infflag=I&userid=${userid}&rsltdesc=${rsltdesc}`;

history back
https://www.bennadel.com/blog/3533-using-router-events-to-detect-back-and-forward-browser-navigation-in-angular-7-0-4.htm

I27460050
*/
