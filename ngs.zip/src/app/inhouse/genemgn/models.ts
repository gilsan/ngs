export interface IGTYPE {
  gene: string;
  type: string;
  test_code?: string;
}
