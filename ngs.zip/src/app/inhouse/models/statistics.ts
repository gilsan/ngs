export interface ITypeForm {
  type: string;
  count: number;
}
