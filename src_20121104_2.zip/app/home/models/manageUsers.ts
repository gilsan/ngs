export interface IManageUsers {
  id: string; 
  user_id: string; 
  password: string; 
  user_nm: string; 
  user_gb: string; 
  user_gb_nm: string; 
  dept: string; 
  dept_nm: string; 
  uuid: string; 
  reg_date: string; 
  pickselect: string; 
  part: string; 
  part_nm: string; 
  login_date: string;
  approved: string;
}