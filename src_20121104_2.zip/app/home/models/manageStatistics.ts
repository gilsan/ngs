export interface IManageStatistics {
  seq : String;
  patientID : string;
  name : string;
  accept_date : string;
  dept : string;
  sender : string;
  send_time : string;
  send_result : string;
  remark: string;
}