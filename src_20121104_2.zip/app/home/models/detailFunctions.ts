export interface IDetailFunctions {
  seq: string; 
  function_id: string; 
  function_name: string;
  service_status: string;
  variable: string; 
  data_type: string; 
  leave_yn: string; 
  inner_variable: string; 
  condition: string;
  data_value : string; 
  outer_condition: string; 
}