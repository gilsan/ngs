// private apiUrl = 'http://160.1.17.79:3000';  // EMR 서버
// private apiUrl = 'http://112.169.53.30:3000';

export const emrUrl = 'http://211.104.56.34:3000';
//export const emrUrl = 'http://211.104.56.34:5000';  //edu

//export const emrUrl = 'http://211.104.56.34:5100';  // devel (연구)

// export const emrUrl = 'http://localhost:3000';
// export const emrUrl = 'http://160.1.17.79:3000';
// export const emrUrl = 'http://160.1.17.79:5000';

//

/*
// tslint:disable-next-line:max-line-length
const emrdata = `http://emr012edu.cmcnu.or.kr/cmcnu/.live?submit_id=${submitID}&business_id=li&instcd=012&spcno=${spcno}&formcd=-&rsltflag=O&pid=${pid}&examcd=${examcd}&examflag=${examflag}&infflag=I&userid=${userid}&rsltdesc=${rsltdesc}`;

history back
https://www.bennadel.com/blog/3533-using-router-events-to-detect-back-and-forward-browser-navigation-in-angular-7-0-4.htm

I27460050
*/
